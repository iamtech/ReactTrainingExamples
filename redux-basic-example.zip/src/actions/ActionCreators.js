// const setTechnology = text => ({ type: "SET_TECHNOLOGY", tech: test });

export function setTechnology (text) {
  return {
     type: "SET_TECHNOLOGY",
     tech: text
   }
}
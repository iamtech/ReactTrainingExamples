import React, { Component } from 'react';
import { render } from 'react-dom';
import { createStore } from 'redux';
import reducer from './reducers/reducer';
import {setTechnology} from './actions/ActionCreators';

import Hello from './Hello';
import './style.css';

const initialState = { tech: "React " }; 
const store = createStore(reducer,initialState);

function dispatchBtnAction(e) {
  if(store.getState().tech == "React ")
    const tech = "Angular ";
  else
      const tech = "React ";
  store.dispatch(setTechnology(tech));
}

const renderAgain = () => render(<App />, document.getElementById("root"));


class App extends Component {

  render() {
    store.subscribe(renderAgain);
    return (
      <div>
        <Hello name={store.getState().tech} />

        <button onClick={dispatchBtnAction}>CHANGE</button>
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));

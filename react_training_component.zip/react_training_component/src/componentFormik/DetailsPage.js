import React from 'react';

export default function DetailsPage(){
    return (
        <div id="details">
          This is the details page.
        </div>
      );
}
import React,  {Component} from 'react';
import { Formik,Form, Field, ErrorMessage } from 'formik';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import ButtonBase from '@material-ui/core/ButtonBase';

import FormStyle from '../componentStyle/FormStyle.css'
import EntryPage from '../componentFormik/EntryPage';
import DetailsPage from '../componentFormik/DetailsPage';

import { Link } from 'react-router-dom'
import { BrowserRouter , Route,  Switch, Prompt, Redirect, matchPath  } from 'react-router-dom';



class BasePage extends Component{

    state = {
        submitted: false,
      };

    handleSubmit = () => {
        this.setState(
          {
            submitted: true,
          },
          () => this.props.history.push("/details"),
        );
      };
   
    render() {
    return (
        
            
                        
                    <BrowserRouter>
                        <Switch>
                            <Redirect from="/" exact to="/entrypage" />
                            <Route path="/entrypage" component={EntryPage} />
                            <Route path="/details" component={DetailsPage} />
                        
                        </Switch>
                    
                    </BrowserRouter>

           
    )}};


export default BasePage;
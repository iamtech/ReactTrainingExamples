import React from 'react';

import FormStyle from '../componentStyle/FormStyle.css'

import DetailsPage from '../componentFormik/DetailsPage';

import { Link } from 'react-router-dom'
import { BrowserRouter , Route,  Switch, Prompt, Redirect, matchPath  } from 'react-router-dom';

import { Formik,Form, Field, ErrorMessage } from 'formik';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import ButtonBase from '@material-ui/core/ButtonBase';


export default function EntryPage(props){

return(
    <div className="BasePage">
        
    <h1>Formik Base Page</h1>
      <Paper className="paper">
        <Grid container>
            <Grid item xs={12} sm container>
                
                <Formik
                initialValues={{ email: '', password: '' }}
                validate={values => {
                    let errors = {};
                    if (!values.email) {
                    errors.email = 'Email Required';
                    } else if (
                    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                    ) {
                    errors.email = 'Invalid email address';
                    }
                    return errors;
                }}

                 onSubmit={(values, { setSubmitting }) => {
                    setTimeout(() => {
                    alert(JSON.stringify(values, null, 2));
                    this.handleSubmit();
                    setSubmitting(false);
                     }, 400);
                 }}

                onReset = { (values, { setSubmitting }) => {
                    alert("FROM RESET");
                }}
                >
                {({ values,
                touched,
                errors,
                dirty,
                isSubmitting,
                handleChange,
                handleBlur,
                handleSubmit,
                handleReset,
                history, }) => (    
               
                    <form onSubmit={handleSubmit.bind(this)}>
                    <label htmlFor="email" style={{ display: 'block' }}>
                        Email
                    </label>
                    <input
                        id="email"
                        placeholder="Enter your email"
                        type="text"
                        value={values.email}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={
                        errors.email && touched.email ? 'text-input error' : 'text-input'
                        }
                    />
                    {errors.email &&
                        touched.email && <div className="input-feedback">{errors.email}</div>}
                        <br/>
                    <button
                        type="button"
                        className="outline"
                        onClick={handleReset}
                        disabled={!dirty || isSubmitting}
                    >
                        Reset
                    </button>
                    {/* <button type="submit" disabled={isSubmitting}>
                        Submit
                    </button> */}
                    <Link to="/details" className="next">Next</Link>
                    
                    </form>

                )}
                                
                    </Formik>
                    </Grid>
                </Grid>
            </Paper>
        </div>
 )
}
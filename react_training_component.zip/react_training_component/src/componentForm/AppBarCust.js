import React,{Component} from 'react'

import Typography from '@material-ui/core/Typography';
import ButtonBase from '@material-ui/core/ButtonBase';

import Button from '@material-ui/core/Button';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import PropTypes from "prop-types";

import {
    BrowserRouter as Router,
    Link,
    withRouter
  } from 'react-router-dom'


class AppBarCust extends Component{
    state = {
        anchorEl: null,
        auth: true
      }

    handleClick = event => {
        this.setState({ anchorEl: event.currentTarget });
    };

    handleClose = () => {
        this.setState({ anchorEl: null });
    };  

    publicPage = () => {
        this.props.history.push('/public');
    };
    
    

    render(){

        const { anchorEl } = this.state;
        const open = Boolean(anchorEl);

    return(
        <AppBar className='appBar' position="static">
                    <Toolbar>
                    <div>
                    <IconButton className='menuButton' color="inherit"
                        aria-owns={open ? 'simple-menu' : undefined}
                        aria-haspopup="true"
                        onClick={this.handleClick}
                        >
                       <MenuIcon/>
                    </IconButton>    
                    
                    <Menu
                        id="simple-menu"
                        anchorEl={anchorEl}
                        open={open}
                        onClose={this.handleClose}
                        >
                        <MenuItem onClick={()=> this.props.history.push('/public')}>Public Page</MenuItem>
                        <MenuItem onClick={()=> this.props.history.push('/protected')}>Protected Page</MenuItem>
                        {/* <Link to="/protected"><MenuItem>Protected Page</MenuItem></Link> */}

                        
                    </Menu>
                    </div>
                    <Typography variant="h6" color="inherit" className='grow'>
                        Application
                    </Typography>
                    <Button color="inherit" onClick = {(event) =>this.login(event)}>Login</Button>
                    </Toolbar>
                </AppBar>
    );
    }
}   

export default withRouter(AppBarCust);
import React, { Component } from 'react';
import AuthRouter, { fakeAuth } from './AuthRouter';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';

import ButtonBase from '@material-ui/core/ButtonBase';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';


import LoginPageStyle from '../componentStyle/LoginPageStyle.css';
import AppBarCust from './AppBarCust';

import {
    BrowserRouter as Router,
    Route,
    Link,
    Redirect,
    withRouter
  } from 'react-router-dom'

 class LoginPage extends Component{
    //  constructor(){
    //      super();
    //      this.state = {
    //         redirectToReferrer: false,
    //         email: ''
    //       }
    //      this.handleInputChange = this.handleInputChange.bind(this);
    //  }

     state = {
        redirectToReferrer: false,
        email: '',
        anchorEl: null,
        auth: true
      }

      login = (event) => {
         
        fakeAuth.authenticate(() => {
          this.setState(() => ({
            redirectToReferrer: true
          }))
        })
        this.props.history.push('/protected')
        // const target = event.target;
        // const value = target.value;
        // const name = target.id;
    
        // this.setState({
        //   [name]: value,
        //   redirectToReferrer : true
        // });

        // console.log('email:'+this.state.email);

        // const { redirectToReferrer } = this.state
        // const { from } = this.props.location.state || { from: { pathname: '/' } }
        // console.log('rendring from:'+ {from});
        // if (redirectToReferrer === true) {
        //     return <Redirect to={from} />
        // }
      }

      validate= (values) => {
        let errors = {};
        if (!values.email) {
        errors.email = 'Email Required';
        } else if (
        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
        ) {
        errors.email = 'Invalid email address';
        }
       
    }

    handleInputChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.id;
    
        this.setState({
          [name]: value
        });
        console.log('email:'+this.state.email);
      }

   
      

    render() {
       // console.log('rendring email:'+this.state.email);
        // const { redirectToReferrer } = this.state
        // const { from } = this.props.location.state || { from: { pathname: '/' } }
        // console.log('rendring from:'+ {from});
        // if (redirectToReferrer === true) {
        //      return <Redirect to={from} />
        // }
        
        
        return (
            <div> 

                <Paper className="paper" elevation = {10}>      
                           <div  className="text-center"> <b>Login Page</b>
                          
                                <form className='formLogin' onSubmit = {(event) =>this.login(event)}>
                                
                                <TextField
                                        placeholder="Email"
                                        label="Email"
                                        type="email"
                                        margin="normal"
                                        variant="outlined"
                                        //  errorText={this.state.email_error_text}
                                        // onChange={(e) => this.changeValue(e, 'email')}
                                />
                                
                                <br/>
                                
                                    <TextField
                                        type="password"
                                        placeholder="Enter your Password"
                                        label="Password"
                                        margin="normal"
                                        variant="outlined"
                                    // onChange = {(event,newValue) => this.setState({password:newValue})}
                                    />
                                    <br/>
                                    
                                    <input className="submitButton" type="submit" value = "Log In"/>
                                    </form>
                                                   
                            </div>  
                  
                </Paper>       
            </div>
        )
    }

 }

export default LoginPage; 
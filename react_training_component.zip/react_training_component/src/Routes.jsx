import React from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import BasePage from './componentFormil/BasePage';
import DetailsPage from './componentFormil/DetailsPage';

const Routes = () => (
    <Router>
      <div>
        <Header />
  
        <Route exact path="/" component={BasePage} />
        <Route path="/about" component={DetailsPage} />
     
      </div>
    </Router>
  );

  ReactDOM.render(routing, document.getElementById('root'))

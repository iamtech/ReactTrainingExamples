export default (state,action)  => {
  console.log("Inside reducer; text:"+action.tech);
  switch (action.type) {
		case "SET_TECHNOLOGY":
			return {
        ...state,  // ES6 spread operator
        tech:action.tech
      };  //return new state
		case "is_angular":
			return; //return new state
		default:
		  return state;
	}
}	   
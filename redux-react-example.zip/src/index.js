import React, { Component } from 'react';
import { render } from 'react-dom';
import { createStore } from 'redux';
import reducer from './reducers/reducer';
import { connect, Provider } from "react-redux";
import {setTechnology} from './actions/ActionCreators';

import Hello from './Hello';
import './style.css';

const initialState = { tech: "React " }; 
const store = createStore(reducer,initialState);

function dispatchBtnAction(e) {
  if(store.getState().tech == "React ")
    const tech = "Angular ";
  else
      const tech = "React ";
  store.dispatch(setTechnology(tech));
}

//const renderAgain = () => render(<App />, document.getElementById("root"));

const mapStateToProps = state => {
  console.log("from mapStatetoProps");
  return { tech: state.tech };
};

class App extends Component {

  constructor(props) {
        super(props);
        this.state = {
            tech: this.props.tech
        };
    }

  render() {
    //store.subscribe(renderAgain);
    return (
      <div>
        <Hello name={store.getState().tech} />

        <button onClick={dispatchBtnAction}>CHANGE</button>
      </div>
    );
  }
}


const AppContainer = connect(mapStateToProps)(App);


render(<Provider store={store}><AppContainer /> </Provider>, document.getElementById('root'));
